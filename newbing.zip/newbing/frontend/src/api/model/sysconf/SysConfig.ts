export interface SysConfig {
  isSysCK: boolean;
  isAuth: boolean;
}
