/* eslint-disable */
(function (n, t) {
  onload = function () {
    _G.BPT = new Date();
    // n && n();
    !_w.sb_ppCPL &&
      t &&
      sb_st(function () {
        t(new Date());
      }, 0);
  };
})(_w.onload, _w.si_PP);
_w.rms.js(
  { 'A:rms:answers:Shared:BingCore.Bundle': '/rp/oJ7sDoXkkNOICsnFb57ZJHBrHcw.br.js' },
  { 'A:rms:answers:Web:SydneyFSCHelper': '/rp/XBHyxbMN-5ifYmS8GGYyywmwILI.br.js' },
  { 'A:rms:answers:VisualSystem:ConversationScope': '/rp/YFRe970EMtFzujI9pBYZBGpdHEo.br.js' },
  { 'A:rms:answers:CodexBundle:cib-bundle': '/rp/-2UI-r71AEUWE8zNKc6Vdf8wVfc.br.js' },
  { 'A:rms:answers:SharedStaticAssets:speech-sdk': '/rp/6slp3E-BqFf904Cz6cCWPY1bh9E.br.js' },
  { 'A:rms:answers:Web:SydneyFullScreenConv': '/rp/R-NU1gYWw5NsYTEXrFn1hwhdP5g.br.js' },
);
